# Shizuku Provider 由 Manifest 注册，避免被 R8 移除
-keep class rikka.shizuku.** { *; }
-dontwarn rikka.shizuku.**

# 本工程数据类通过反射/JSON 手动读写，保留字段名
-keep class com.yuanbao.multispace.** { *; }
-keepattributes Signature
-keepattributes *Annotation*
