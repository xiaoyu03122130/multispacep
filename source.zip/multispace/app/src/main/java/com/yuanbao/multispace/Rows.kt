package com.yuanbao.multispace

import android.content.ComponentName
import android.graphics.drawable.Drawable
import android.os.UserHandle

/** 主用户里一个可启动应用 */
data class AppEntry(
    val pkg: String,
    val label: String,
    val icon: Drawable,
    val component: ComponentName
)

/** 某个 UserHandle 下该应用的一个实例（主实例 / 厂商分身 / 工作资料） */
data class Instance(
    val label: String,
    val user: UserHandle,
    val component: ComponentName,
    val icon: Drawable,
    val isPrimary: Boolean
)

/** 自建空间里已装的应用 */
data class SpaceApp(
    val pkg: String,
    val label: String,
    val component: ComponentName
)

/** 通过 Shizuku 创建的系统级隔离用户 */
data class ExtraSpace(
    val id: Int,
    val name: String,
    val createdAt: Long,
    val apps: MutableList<SpaceApp> = mutableListOf()
)

sealed class Row {
    data class Header(val text: String) : Row()
    data class Hint(val text: String) : Row()
    data class SystemApp(val app: AppEntry, val instances: List<Instance>) : Row()
    data class Space(val space: ExtraSpace) : Row()
}
