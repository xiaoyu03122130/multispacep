package com.yuanbao.multispace.oem

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build

enum class Rom { XIAOMI, OPPO, VIVO, HUAWEI, HONOR, SAMSUNG, AOSP }

/** 只用公开 Build 字段 + 特征包存在性做判定，不反射 hidden API */
object RomDetector {

    fun detect(ctx: Context): Rom {
        val fingerprint = listOf(
            Build.MANUFACTURER,
            Build.BRAND,
            Build.DISPLAY,
            Build.FINGERPRINT,
            Build.PRODUCT
        ).joinToString(" ").lowercase()

        return when {
            "xiaomi" in fingerprint || "redmi" in fingerprint || "poco" in fingerprint ||
                has(ctx, "com.miui.securitycenter") -> Rom.XIAOMI

            "samsung" in fingerprint || has(ctx, "com.samsung.android.lool") -> Rom.SAMSUNG

            "honor" in fingerprint -> Rom.HONOR

            "huawei" in fingerprint || "harmony" in fingerprint || "emui" in fingerprint -> Rom.HUAWEI

            "oppo" in fingerprint || "oneplus" in fingerprint || "realme" in fingerprint ||
                "coloros" in fingerprint || has(ctx, "com.coloros.securitypermission") -> Rom.OPPO

            "vivo" in fingerprint || "iqoo" in fingerprint -> Rom.VIVO

            else -> Rom.AOSP
        }
    }

    fun label(rom: Rom): String = when (rom) {
        Rom.XIAOMI -> "小米 / Redmi / POCO"
        Rom.OPPO -> "OPPO / 一加 / realme"
        Rom.VIVO -> "vivo / iQOO"
        Rom.HUAWEI -> "华为"
        Rom.HONOR -> "荣耀"
        Rom.SAMSUNG -> "三星"
        Rom.AOSP -> "AOSP / 类原生"
    }

    private fun has(ctx: Context, pkg: String): Boolean = try {
        ctx.packageManager.getPackageInfo(pkg, 0)
        true
    } catch (e: PackageManager.NameNotFoundException) {
        false
    } catch (t: Throwable) {
        false
    }
}
