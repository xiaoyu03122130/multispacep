package com.yuanbao.multispace

import android.content.ComponentName
import android.content.Context
import android.content.pm.LauncherApps
import android.content.pm.LauncherActivityInfo
import android.graphics.drawable.Drawable
import android.os.UserHandle

/**
 * 系统启动器通道。
 *
 * 这是「和原生一样丝滑」的关键：不重打包 APK、不 hook、不转发 Intent，
 * 直接通过 LauncherApps 枚举各 UserHandle 下的实例并用 startMainActivity 拉起，
 * 与用户点击桌面图标走的是同一条系统路径，共享 Activity 栈与转场动画。
 */
class LauncherBridge(ctx: Context) {

    private val app = ctx.applicationContext
    private val launcherApps = app.getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps
    private val dpi = app.resources.displayMetrics.densityDpi

    /** 当前调用方可访问的资料：主用户 + 工作资料 / 厂商分身 */
    fun profiles(): List<UserHandle> = try {
        launcherApps.profiles
    } catch (t: Throwable) {
        emptyList()
    }

    /** UserHandle 的数字 ID 没有公开 getter，反射取不到时降级为 -1（不影响启动） */
    fun userId(user: UserHandle): Int = try {
        UserHandle::class.java
            .getDeclaredMethod("getIdentifier")
            .apply { isAccessible = true }
            .invoke(user) as Int
    } catch (t: Throwable) {
        -1
    }

    /** 按包名聚合所有资料下的可启动实例 */
    fun allLaunchables(): Map<String, List<Instance>> {
        val result = linkedMapOf<String, MutableList<Instance>>()
        val ps = profiles()
        val primary = ps.firstOrNull()
        for (u in ps) {
            val activities: List<LauncherActivityInfo> = try {
                launcherApps.getActivityList(null, u)
            } catch (t: Throwable) {
                continue
            }
            for (info in activities) {
                val comp = info.componentName
                val pkg = comp.packageName
                if (pkg == app.packageName) continue
                val isPrimary = (u == primary)
                val id = userId(u)
                val label = when {
                    isPrimary -> "主实例"
                    id > 0 -> "系统分身 · u$id"
                    else -> "系统分身"
                }
                val icon: Drawable = try {
                    info.getBadgedIconDrawable(dpi)
                } catch (t: Throwable) {
                    info.getIcon(dpi)
                }
                result.getOrPut(pkg) { mutableListOf() }
                    .add(Instance(label, u, comp, icon, isPrimary))
            }
        }
        return result
    }

    /** 主用户应用清单，用于「添加应用到空间」的选择器 */
    fun primaryApps(map: Map<String, List<Instance>> = allLaunchables()): List<AppEntry> =
        map.mapNotNull { (pkg, instances) ->
            val p = instances.firstOrNull { it.isPrimary } ?: instances.firstOrNull() ?: return@mapNotNull null
            val label = try {
                app.packageManager.getApplicationLabel(
                    app.packageManager.getApplicationInfo(pkg, 0)
                ).toString()
            } catch (t: Throwable) {
                p.component.packageName
            }
            AppEntry(pkg, label, p.icon, p.component)
        }.sortedBy { it.label }

    fun start(component: ComponentName, user: UserHandle): Boolean = try {
        launcherApps.startMainActivity(component, user, null, null)
        true
    } catch (t: Throwable) {
        false
    }

    fun hasUser(userId: Int): Boolean = profiles().any { userId(it) == userId }
}
