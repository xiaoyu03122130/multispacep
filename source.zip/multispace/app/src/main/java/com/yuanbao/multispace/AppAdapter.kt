package com.yuanbao.multispace

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.chip.Chip
import com.yuanbao.multispace.databinding.RowHeaderBinding
import com.yuanbao.multispace.databinding.RowHintBinding
import com.yuanbao.multispace.databinding.RowSpaceBinding
import com.yuanbao.multispace.databinding.RowSystemAppBinding

class AppAdapter(
    private val onInstance: (Instance) -> Unit,
    private val onAddApp: (ExtraSpace) -> Unit,
    private val onDeleteSpace: (ExtraSpace) -> Unit,
    private val onSpaceApp: (ExtraSpace, SpaceApp) -> Unit,
    private val onRemoveApp: (ExtraSpace, SpaceApp) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private val rows = mutableListOf<Row>()

    fun submit(list: List<Row>) {
        rows.clear()
        rows.addAll(list)
        notifyDataSetChanged()
    }

    override fun getItemViewType(position: Int): Int = when (rows[position]) {
        is Row.Header -> 0
        is Row.Hint -> 1
        is Row.SystemApp -> 2
        is Row.Space -> 3
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inf = LayoutInflater.from(parent.context)
        return when (viewType) {
            0 -> HeaderVH(RowHeaderBinding.inflate(inf, parent, false))
            1 -> HintVH(RowHintBinding.inflate(inf, parent, false))
            2 -> SystemVH(RowSystemAppBinding.inflate(inf, parent, false))
            else -> SpaceVH(RowSpaceBinding.inflate(inf, parent, false))
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val row = rows[position]) {
            is Row.Header -> (holder as HeaderVH).b.tvHeader.text = row.text
            is Row.Hint -> (holder as HintVH).b.tvHint.text = row.text
            is Row.SystemApp -> bindSystem(holder as SystemVH, row)
            is Row.Space -> bindSpace(holder as SpaceVH, row)
        }
    }

    override fun getItemCount(): Int = rows.size

    private fun bindSystem(h: SystemVH, row: Row.SystemApp) {
        val b = h.b
        b.ivIcon.setImageDrawable(row.app.icon)
        b.tvLabel.text = row.app.label
        b.tvPkg.text = "${row.app.pkg} · ${row.instances.size} 个实例"
        b.chipGroup.removeAllViews()
        for (ins in row.instances) {
            val c = chip(b.root.context, ins.label)
            c.setOnClickListener { onInstance(ins) }
            b.chipGroup.addView(c)
        }
    }

    private fun bindSpace(h: SpaceVH, row: Row.Space) {
        val b = h.b
        val space = row.space
        b.tvSpaceName.text = space.name
        b.tvSpaceMeta.text = "系统用户 u${space.id} · ${space.apps.size} 个应用 · 数据独立"
        b.btnAddApp.setOnClickListener { onAddApp(space) }
        b.btnDelete.setOnClickListener { onDeleteSpace(space) }

        b.chipGroup.removeAllViews()
        if (space.apps.isEmpty()) {
            val c = chip(b.root.context, "还没有应用 · 点「添加应用」")
            c.isClickable = false
            b.chipGroup.addView(c)
            return
        }
        for (app in space.apps) {
            val c = chip(b.root.context, app.label)
            c.setOnClickListener { onSpaceApp(space, app) }
            c.setOnLongClickListener {
                onRemoveApp(space, app)
                true
            }
            b.chipGroup.addView(c)
        }
    }

    private fun chip(ctx: Context, text: String): Chip = Chip(ctx).apply {
        this.text = text
        isCheckable = false
        isClickable = true
    }

    private class HeaderVH(val b: RowHeaderBinding) : RecyclerView.ViewHolder(b.root)
    private class HintVH(val b: RowHintBinding) : RecyclerView.ViewHolder(b.root)
    private class SystemVH(val b: RowSystemAppBinding) : RecyclerView.ViewHolder(b.root)
    private class SpaceVH(val b: RowSpaceBinding) : RecyclerView.ViewHolder(b.root)
}
