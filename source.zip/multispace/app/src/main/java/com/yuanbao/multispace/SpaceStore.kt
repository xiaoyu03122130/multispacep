package com.yuanbao.multispace

import android.content.ComponentName
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** 只保存「本应用创建过的空间」及其用户 ID，系统自带的厂商分身不写入这里 */
class SpaceStore(ctx: Context) {

    private val sp = ctx.applicationContext.getSharedPreferences("extra_spaces", Context.MODE_PRIVATE)

    companion object {
        private const val KEY = "spaces"
    }

    fun list(): MutableList<ExtraSpace> {
        val raw = sp.getString(KEY, "[]") ?: "[]"
        val result = mutableListOf<ExtraSpace>()
        val arr = try {
            JSONArray(raw)
        } catch (e: Throwable) {
            return result
        }
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val apps = mutableListOf<SpaceApp>()
            val ja = o.optJSONArray("apps") ?: JSONArray()
            for (j in 0 until ja.length()) {
                val a = ja.optJSONObject(j) ?: continue
                val comp = ComponentName.unflattenFromString(a.optString("component")) ?: continue
                apps += SpaceApp(a.optString("pkg"), a.optString("label", a.optString("pkg")), comp)
            }
            result += ExtraSpace(
                id = o.optInt("id", -1),
                name = o.optString("name", "分身"),
                createdAt = o.optLong("createdAt", 0L),
                apps = apps
            )
        }
        return result.filter { it.id > 0 }.toMutableList()
    }

    fun save(list: List<ExtraSpace>) {
        val arr = JSONArray()
        for (s in list) {
            val ja = JSONArray()
            for (a in s.apps) {
                ja.put(
                    JSONObject()
                        .put("pkg", a.pkg)
                        .put("label", a.label)
                        .put("component", a.component.flattenToString())
                )
            }
            arr.put(
                JSONObject()
                    .put("id", s.id)
                    .put("name", s.name)
                    .put("createdAt", s.createdAt)
                    .put("apps", ja)
            )
        }
        sp.edit().putString(KEY, arr.toString()).apply()
    }
}
