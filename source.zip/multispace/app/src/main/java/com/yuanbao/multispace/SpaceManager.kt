package com.yuanbao.multispace

import android.content.Context

/**
 * 叠加 N 开：在系统已有的「主实例 + 厂商分身」之外，再创建系统级隔离用户。
 *
 * 优先创建 managed profile（会出现在 LauncherApps.getProfiles()，启动最丝滑）；
 * 若槽位被厂商分身占满 / ROM 报上限，则降级为普通 secondary user，
 * 数据依旧内核级隔离，启动改走 am start --user。
 */
class SpaceManager(private val ctx: Context, private val store: SpaceStore) {

    companion object {
        private val SAFE_NAME = Regex("""^[\u4e00-\u9fa5A-Za-z0-9_\-]{1,16}$""")
        private val SAFE_PKG = Regex("""^[A-Za-z][A-Za-z0-9_.]+$""")
        private val ID_RE = Regex("""id\s*[=:]?\s*(\d+)""")
    }

    fun create(name: String): Result<ExtraSpace> {
        if (!SAFE_NAME.matches(name)) {
            return Result.failure(IllegalArgumentException("名称仅支持中英文、数字、下划线、短横线，最多 16 字"))
        }
        if (!ShizukuShell.hasPermission()) {
            return Result.failure(IllegalStateException("Shizuku 尚未授权"))
        }

        var r = ShizukuShell.exec(listOf("pm", "create-user", "--profileOf", "0", "--managed", name))
        if (!r.ok) {
            r = ShizukuShell.exec(listOf("pm", "create-user", name))
        }
        if (!r.ok) {
            return Result.failure(
                IllegalStateException("创建用户失败：${r.text.trim()}\n若提示用户数已达上限，请先删除不再使用的空间。")
            )
        }

        val id = ID_RE.find(r.text)?.groupValues?.getOrNull(1)?.toIntOrNull()
            ?: return Result.failure(IllegalStateException("未能解析新用户 ID：${r.text.trim()}"))
        if (id <= 0) return Result.failure(IllegalStateException("拒绝操作主用户"))

        ShizukuShell.exec(listOf("am", "start-user", id.toString()))

        val space = ExtraSpace(id, name, System.currentTimeMillis())
        val all = store.list()
        all.add(space)
        store.save(all)
        return Result.success(space)
    }

    /** 零拷贝：共用同一个已安装 APK，不复制 dex、不重签名 */
    fun addApp(space: ExtraSpace, app: AppEntry): Result<Unit> {
        if (!SAFE_PKG.matches(app.pkg)) {
            return Result.failure(IllegalArgumentException("非法包名"))
        }
        val r = ShizukuShell.exec(
            listOf("pm", "install-existing", "--user", space.id.toString(), app.pkg)
        )
        if (!r.ok) {
            return Result.failure(
                IllegalStateException(
                    "安装到空间失败：${r.text.trim()}\n\n" +
                        "小米/Redmi 请到「开发者选项」打开「USB 调试(安全设置)」；\n" +
                        "一加/realme 请打开「设置 → 多用户」开关。"
                )
            )
        }
        val all = store.list()
        val target = all.firstOrNull { it.id == space.id }
            ?: return Result.failure(IllegalStateException("空间记录丢失，请重建"))
        if (target.apps.none { it.pkg == app.pkg }) {
            target.apps.add(SpaceApp(app.pkg, app.label, app.component))
        }
        store.save(all)
        return Result.success(Unit)
    }

    fun removeApp(space: ExtraSpace, pkg: String) {
        ShizukuShell.exec(listOf("pm", "uninstall", "--user", space.id.toString(), pkg))
        val all = store.list()
        all.firstOrNull { it.id == space.id }?.apps?.removeAll { it.pkg == pkg }
        store.save(all)
    }

    /** 硬保护：永远不允许删除 User 0 */
    fun delete(space: ExtraSpace): Result<Unit> {
        if (space.id <= 0) {
            return Result.failure(IllegalStateException("拒绝删除主用户"))
        }
        val r = ShizukuShell.exec(listOf("pm", "remove-user", space.id.toString()))
        if (!r.ok) {
            return Result.failure(IllegalStateException("删除失败：${r.text.trim()}"))
        }
        val all = store.list()
        all.removeAll { it.id == space.id }
        store.save(all)
        return Result.success(Unit)
    }

    /**
     * 启动空间里的应用：managed profile 走 LauncherApps（原生体验），
     * 普通 secondary user 才退回 am start。
     */
    fun launch(space: ExtraSpace, app: SpaceApp, bridge: LauncherBridge): Boolean {
        val handle = bridge.profiles().firstOrNull { bridge.userId(it) == space.id }
        if (handle != null && bridge.start(app.component, handle)) return true

        val r = ShizukuShell.exec(
            listOf("am", "start", "--user", space.id.toString(), "-n", app.component.flattenToString())
        )
        return r.ok
    }
}
