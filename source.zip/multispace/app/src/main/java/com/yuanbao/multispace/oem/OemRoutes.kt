package com.yuanbao.multispace.oem

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings

/**
 * 厂商分身设置页。
 *
 * 重要：这些是系统私有页面，没有公开 SDK。第三方应用既不能代用户拨开关，
 * 也不能把「每应用 1 个分身」改成 N 个。本模块只负责把用户带到设置页，
 * 因此每个候选组件在 startActivity 之前都用 resolveActivity 校验，
 * 失败会自动降级到通用的应用设置页 / 设置首页，并给出手动路径文字。
 *
 * candidates 里是按机型/版本可能变化的参考值；若你的机型跳不准，
 * 把正确的 ComponentName 追加进来即可，主流程不依赖它。
 */
data class OemRoute(
    val title: String,
    val manualPath: String,
    val candidates: List<ComponentName>
)

private fun cn(pkg: String, cls: String) = ComponentName(pkg, cls)

fun oemRoute(rom: Rom): OemRoute = when (rom) {
    Rom.XIAOMI -> OemRoute(
        "应用双开",
        "设置 → 应用设置 → 应用双开",
        listOf(
            cn("com.miui.securitycenter", "com.miui.appmanager.ApplicationsManagerActivity"),
            cn("com.android.settings", "com.android.settings.Settings\$DualAppSettingsActivity")
        )
    )

    Rom.OPPO -> OemRoute(
        "应用分身",
        "设置 → 应用 → 应用分身",
        listOf(
            cn("com.android.settings", "com.android.settings.Settings\$AppCloneSettingsActivity"),
            cn("com.coloros.settings", "com.coloros.settings.feature.AppCloneActivity")
        )
    )

    Rom.VIVO -> OemRoute(
        "应用分身",
        "设置 → 应用与权限 → 应用分身",
        listOf(
            cn("com.android.settings", "com.android.settings.Settings\$AppCloneSettingsActivity"),
            cn("com.vivo.settings", "com.vivo.settings.AppCloneActivity")
        )
    )

    Rom.HUAWEI, Rom.HONOR -> OemRoute(
        "应用分身",
        "设置 → 应用和服务 → 应用分身",
        listOf(
            cn("com.android.settings", "com.android.settings.Settings\$AppCloneSettingsActivity")
        )
    )

    Rom.SAMSUNG -> OemRoute(
        "双信使 / Dual Messenger",
        "设置 → 高级功能 → Dual Messenger",
        listOf(
            cn("com.android.settings", "com.android.settings.Settings\$DualMessengerSettingsActivity")
        )
    )

    Rom.AOSP -> OemRoute(
        "应用设置",
        "类原生系统通常无厂商分身入口；可直接用下方的「新建空间」叠加系统用户",
        emptyList()
    )
}

/** 返回是否成功拉起了某个设置页；UI 层在失败时展示 manualPath */
fun openOemSettings(ctx: Context, rom: Rom): Boolean {
    val route = oemRoute(rom)

    for (c in route.candidates) {
        val intent = Intent(Intent.ACTION_MAIN)
            .setComponent(c)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (intent.resolveActivity(ctx.packageManager) == null) continue
        try {
            ctx.startActivity(intent)
            return true
        } catch (t: Throwable) {
            // 继续尝试下一个候选
        }
    }

    for (action in listOf(Settings.ACTION_APPLICATION_SETTINGS, Settings.ACTION_SETTINGS)) {
        val intent = Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (intent.resolveActivity(ctx.packageManager) == null) continue
        try {
            ctx.startActivity(intent)
            return true
        } catch (t: Throwable) {
            // 继续降级
        }
    }
    return false
}
