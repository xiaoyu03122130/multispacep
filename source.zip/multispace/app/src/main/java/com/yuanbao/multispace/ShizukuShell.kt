package com.yuanbao.multispace

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.util.concurrent.atomic.AtomicReference

data class ShellResult(val code: Int, val out: String, val err: String) {
    val ok: Boolean get() = code == 0
    val text: String get() = out + err
}

/**
 * 借 Shizuku 拿到的 adb/shell 身份执行 pm / am 命令。
 * 不使用 su、不依赖 root、不引入 hidden API 绕过库。
 */
object ShizukuShell {

    private val ENV = arrayOf(
        "PATH=/system/bin:/product/bin:/system/xbin:/apex/com.android.runtime/bin:/apex/com.android.art/bin",
        "ANDROID_ROOT=/system",
        "ANDROID_ASSETS=/system",
        "ANDROID_DATA=/data",
        "ANDROID_STORAGE=/storage",
        "EXTERNAL_STORAGE=/sdcard",
        "HOME=/data/local/tmp"
    )

    fun isRunning(): Boolean = try {
        Shizuku.pingBinder()
    } catch (t: Throwable) {
        false
    }

    fun hasPermission(): Boolean = try {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (t: Throwable) {
        false
    }

    fun requestPermission() {
        try {
            Shizuku.requestPermission(0)
        } catch (t: Throwable) {
            // Shizuku 未安装或版本过旧时保持基础模式
        }
    }

    fun exec(args: List<String>): ShellResult {
        if (!isRunning()) return ShellResult(-1, "", "Shizuku 服务未运行")
        if (!hasPermission()) return ShellResult(-1, "", "Shizuku 未授权")

        val process: Process = try {
            Shizuku.newProcess(args.toTypedArray(), ENV, null)
        } catch (t: Throwable) {
            return ShellResult(-2, "", t.message ?: "无法创建 shell 进程")
        }

        return try {
            val out = AtomicReference("")
            val err = AtomicReference("")
            val t1 = Thread { out.set(readAll(process.inputStream)) }
            val t2 = Thread { err.set(readAll(process.errorStream)) }
            t1.start(); t2.start()
            val code = process.waitFor()
            t1.join(3000); t2.join(3000)
            ShellResult(code, out.get(), err.get())
        } catch (t: Throwable) {
            process.destroy()
            ShellResult(-3, "", t.message ?: "命令执行失败")
        }
    }

    private fun readAll(stream: InputStream): String {
        val sb = StringBuilder()
        try {
            BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { reader ->
                while (true) {
                    val line = reader.readLine() ?: break
                    sb.append(line).append('\n')
                }
            }
        } catch (ignored: Throwable) {
        }
        return sb.toString()
    }
}
