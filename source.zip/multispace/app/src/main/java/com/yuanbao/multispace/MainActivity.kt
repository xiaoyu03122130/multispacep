package com.yuanbao.multispace

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.yuanbao.multispace.databinding.ActivityMainBinding
import com.yuanbao.multispace.oem.RomDetector
import com.yuanbao.multispace.oem.oemRoute
import com.yuanbao.multispace.oem.openOemSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var bridge: LauncherBridge
    private lateinit var store: SpaceStore
    private lateinit var manager: SpaceManager
    private lateinit var adapter: AppAdapter

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { _, _ -> refresh() }

    private val profileReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) = refresh()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        bridge = LauncherBridge(this)
        store = SpaceStore(this)
        manager = SpaceManager(this, store)

        adapter = AppAdapter(
            onInstance = ::launchInstance,
            onAddApp = ::pickAppForSpace,
            onDeleteSpace = ::confirmDeleteSpace,
            onSpaceApp = ::launchSpaceApp,
            onRemoveApp = ::confirmRemoveApp
        )
        binding.rv.layoutManager = LinearLayoutManager(this)
        binding.rv.adapter = adapter

        binding.btnOem.setOnClickListener { openOem() }
        binding.btnNewSpace.setOnClickListener { onNewSpace() }

        Shizuku.addRequestPermissionResultListener(permissionListener)
        ContextCompat.registerReceiver(
            this,
            profileReceiver,
            IntentFilter().apply {
                addAction(Intent.ACTION_MANAGED_PROFILE_ADDED)
                addAction(Intent.ACTION_MANAGED_PROFILE_REMOVED)
            },
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        try {
            unregisterReceiver(profileReceiver)
        } catch (ignored: Throwable) {
        }
        super.onDestroy()
    }

    // ---------------------------------------------------------------- 列表

    private fun refresh() = lifecycleScope.launch {
        val running = ShizukuShell.isRunning()
        val granted = running && ShizukuShell.hasPermission()

        binding.tvMode.text = when {
            granted -> "增强模式 · Shizuku 已连接，可叠加任意多个分身空间"
            running -> "基础模式 · Shizuku 未授权"
            else -> "基础模式 · 系统分身（主实例 + 1 个厂商分身）"
        }
        binding.tvHint.text = when {
            !running -> "未检测到 Shizuku。当前仍可统一管理、一键原生拉起系统自带分身；授权后解锁 2+N 开。"
            !granted -> "Shizuku 正在运行但未授权，点「+ 新建空间」即可申请。"
            else -> "新空间使用系统多用户隔离，共用同一 APK、数据内核级独立，启动走系统通道。"
        }

        val rows = withContext(Dispatchers.IO) { buildRows() }
        adapter.submit(rows)
    }

    private fun buildRows(): List<Row> {
        val out = mutableListOf<Row>()
        val map = bridge.allLaunchables()
        val apps = bridge.primaryApps(map)

        out += Row.Header("系统实例 · ${apps.size} 个应用 / ${map.values.sumOf { it.size }} 个实例")
        if (map.isEmpty()) {
            out += Row.Hint("未读到可启动应用。请确认系统允许本应用查询应用列表，或重新打开本页。")
        }
        for (app in apps) {
            out += Row.SystemApp(app, map[app.pkg].orEmpty())
        }

        val spaces = store.list()
        out += Row.Header("我的分身空间 · ${spaces.size}")
        if (spaces.isEmpty()) {
            out += Row.Hint("还没有自建空间。授权 Shizuku 后点「+ 新建空间」，就能在原应用和厂商分身之外继续叠加。")
        }
        for (s in spaces) {
            out += Row.Space(s)
        }
        return out
    }

    // ---------------------------------------------------------------- 启动

    private fun launchInstance(ins: Instance) {
        if (!bridge.start(ins.component, ins.user)) {
            alert("启动失败", "系统拒绝了启动，可能该工作资料已被暂停。请到系统设置里重新开启「工作应用」后重试。")
        }
    }

    private fun launchSpaceApp(space: ExtraSpace, app: SpaceApp) {
        if (!manager.launch(space, app, bridge)) {
            alert(
                "启动失败",
                "请让「多域」保持在前台再试。部分 Android 14+ 机型会限制后台跨用户启动；" +
                    "也可先在系统「多用户」设置里启用用户 u${space.id}。"
            )
        }
    }

    // ---------------------------------------------------------------- 厂商分身入口

    private fun openOem() {
        val rom = RomDetector.detect(this)
        val route = oemRoute(rom)
        val ok = openOemSettings(this, rom)
        if (ok) {
            toast("手动路径：${route.manualPath}", Toast.LENGTH_LONG)
        } else {
            alert(
                "${RomDetector.label(rom)} · ${route.title}",
                "没找到可直接跳转的设置页，请手动前往：\n\n${route.manualPath}\n\n" +
                    "开关由系统控制，本应用只负责带路，不能代开或增加每应用的分身上限。"
            )
        }
    }

    // ---------------------------------------------------------------- 新建 / 删除空间

    private fun onNewSpace() {
        if (!ShizukuShell.isRunning()) {
            showGuide()
            return
        }
        if (!ShizukuShell.hasPermission()) {
            ShizukuShell.requestPermission()
            toast("请在弹窗中允许，授权后自动刷新")
            return
        }

        val input = EditText(this).apply {
            hint = "例如：分身2"
            setSingleLine(true)
        }
        val pad = (20 * resources.displayMetrics.density).toInt()
        input.setPadding(pad, pad / 2, pad, 0)

        MaterialAlertDialogBuilder(this)
            .setTitle("新建分身空间")
            .setMessage(
                "将创建一个系统级隔离用户（优先工作资料；若槽位被厂商分身占用，自动降级为独立用户）。\n" +
                    "创建后再「添加应用」即可多开，APK 共用、不复制、不重签名。"
            )
            .setView(input)
            .setNegativeButton("取消", null)
            .setPositiveButton("创建") { _, _ -> doCreate(input.text.toString().trim()) }
            .show()
    }

    private fun showGuide() {
        alert(
            "解锁多开需要 Shizuku",
            "Shizuku 让普通应用以 adb/shell 身份调用系统 API，不需要 root，也不改动系统分区。\n\n" +
                "· Android 13+：装 Shizuku → 开发者选项打开「无线调试」→ 在 Shizuku 里无线调试启动（配对一次，之后可在信任 WLAN 自启）\n" +
                "· Android 11 / 12：每次重启后到 Shizuku 点一次「启动」\n" +
                "· Android 8 ~ 10：用电脑执行一次 Shizuku App 内给出的 adb 启动命令\n\n" +
                "完成后回到本应用，点「+ 新建空间」并在弹窗中允许即可。\n\n" +
                "不装也能用：基础模式照样统一管理并原生启动系统分身。"
        )
    }

    private fun doCreate(name: String) = lifecycleScope.launch {
        val progress = MaterialAlertDialogBuilder(this@MainActivity)
            .setTitle("正在创建…")
            .setMessage("正在向系统申请新的隔离用户，请稍候")
            .setCancelable(false)
            .create()
        progress.show()
        val result = withContext(Dispatchers.IO) { manager.create(name) }
        progress.dismiss()
        result
            .onSuccess { toast("已创建 u${it.id}，现在可以「添加应用」了"); refresh() }
            .onFailure { alert("创建失败", it.message ?: "未知错误") }
    }

    private fun pickAppForSpace(space: ExtraSpace) = lifecycleScope.launch {
        val apps = withContext(Dispatchers.IO) { bridge.primaryApps() }
        if (apps.isEmpty()) {
            toast("没有读到可添加的应用")
            return@launch
        }
        MaterialAlertDialogBuilder(this@MainActivity)
            .setTitle("添加到「${space.name}」")
            .setItems(apps.map { it.label }.toTypedArray()) { _, which ->
                addApp(space, apps[which])
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun addApp(space: ExtraSpace, app: AppEntry) = lifecycleScope.launch {
        val result = withContext(Dispatchers.IO) { manager.addApp(space, app) }
        result
            .onSuccess { toast("已添加 ${app.label}"); refresh() }
            .onFailure { alert("添加失败", it.message ?: "未知错误") }
    }

    private fun confirmDeleteSpace(space: ExtraSpace) {
        MaterialAlertDialogBuilder(this)
            .setTitle("删除「${space.name}」？")
            .setMessage("将移除系统用户 u${space.id} 及其全部应用数据，不可恢复。主用户与厂商分身不受影响。")
            .setNegativeButton("取消", null)
            .setPositiveButton("删除") { _, _ ->
                lifecycleScope.launch {
                    val r = withContext(Dispatchers.IO) { manager.delete(space) }
                    r.onSuccess { toast("已删除"); refresh() }
                        .onFailure { alert("删除失败", it.message ?: "未知错误") }
                }
            }
            .show()
    }

    private fun confirmRemoveApp(space: ExtraSpace, app: SpaceApp) {
        MaterialAlertDialogBuilder(this)
            .setTitle("从「${space.name}」移除 ${app.label}？")
            .setMessage("只卸载该空间内的实例，主用户里的原应用不受影响；该空间内的账号数据会被清除。")
            .setNegativeButton("取消", null)
            .setPositiveButton("移除") { _, _ ->
                lifecycleScope.launch {
                    withContext(Dispatchers.IO) { manager.removeApp(space, app.pkg) }
                    refresh()
                }
            }
            .show()
    }

    // ---------------------------------------------------------------- 小工具

    private fun toast(text: String, duration: Int = Toast.LENGTH_SHORT) =
        Toast.makeText(this, text, duration).show()

    private fun alert(title: String, message: String) =
        MaterialAlertDialogBuilder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("知道了", null)
            .show()
}
