# 多域 · Android 应用多开器（完整可编译工程）

零敏感权限时，统一管理并**原生拉起**「主实例 + 厂商分身」；授权 Shizuku 后，在系统原有分身之外叠加任意多个系统级隔离用户，做到 **2+N 开**。

不重打包 APK、不 hook、不 root、不代理任何应用数据。

---

## 一、为什么厂商那个开关改不了

小米 / OPPO / vivo / 华为 / 三星的「应用分身」是系统设置里的私有实现，每应用固定 1 个分身，底层大多就是 Android 的 Managed Profile。第三方应用既拿不到代开开关的接口，也没有办法把上限改成 N。任何声称能改的，实际都是另起一套实现。

本工程不碰这个开关，而是**换一条系统身份**：

| 模式 | 可得实例 | 启动通道 |
|---|---|---|
| 基础（零权限） | 主实例 + 1 个厂商分身 | `LauncherApps.startMainActivity` |
| 增强（Shizuku） | 上面 2 个 + N 个自建空间 | managed profile 同上；普通用户 `am start --user` |

---

## 二、原理（为什么能接近原生丝滑）

- 工作资料 / secondary user 在框架里就是独立 user：`uid = 100000 × userid + appid`，数据落在 `/data/user/<id>`，隔离是内核级、账号体系独立。
- `LauncherApps.getProfiles()` 会把主用户与关联资料一起交给调用方，`getActivityList()` 能拿到各资料里带角标的图标，`startMainActivity()` 与点桌面图标走同一条系统路径——共享 Activity 栈、转场动画、通知角标，没有中间层转发。
- 自建空间用 `pm install-existing --user <id> <包名>`：**零拷贝共用同一个已安装 APK**，不复制 dex、不重新签名，所以没有虚拟化框架的性能损耗和兼容问题。
- Shizuku 只是把 adb/shell 身份借给普通应用（UID 2000 级别的合法调试通道），通过 Binder 直接调系统服务，开销极小。

---

## 三、工程结构

```
multispace/
├── settings.gradle.kts / build.gradle.kts / gradle.properties
├── gradlew / gradlew.bat / gradle/wrapper/*        # Gradle 8.9 Wrapper
├── keystore.properties.example / .gitignore
├── README.md
└── app/
    ├── build.gradle.kts / proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── res/{values,drawable,layout}/*
        └── java/com/yuanbao/multispace/
            ├── MainActivity.kt        界面与交互
            ├── AppAdapter.kt          RecyclerView（4 种行类型）
            ├── Rows.kt                数据模型
            ├── LauncherBridge.kt      ★ 系统启动器通道（原生启动）
            ├── SpaceStore.kt          自建空间持久化
            ├── ShizukuShell.kt        ★ adb/shell 命令执行
            ├── SpaceManager.kt        ★ 建用户 / 装应用 / 启动 / 删除
            └── oem/
                ├── RomDetector.kt     ROM 识别
                └── OemRoutes.kt       分身设置页跳转 + 降级
```

技术栈：Kotlin 2.0.21 / AGP 8.7.3 / Gradle 8.9 / compileSdk 35 / minSdk 26（Android 8+）/ ViewBinding / Material 3 / Shizuku API 13.1.5。

---

## 四、打包成 APK

> 交付的是源码工程；APK 需在你本地生成。

**环境**：JDK 17、Android Studio Ladybug(2024.2) 或更新、Android SDK Platform 35 + Build-Tools 35.0.0。

```bash
cd multispace
./gradlew assembleDebug
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

**出正式签名包**：

```bash
keytool -genkeypair -v -keystore release.jks -alias multispace \
  -keyalg RSA -keysize 2048 -validity 10000
cp keystore.properties.example keystore.properties   # 填入你刚设置的密码
./gradlew assembleRelease
# 产物：app/build/outputs/apk/release/app-release.apk
```

`keystore.properties` 已在 `.gitignore` 中，不要提交。debug 包带 `.debug` 后缀，可与正式包共存。也可以直接用 Android Studio：`File → Open` 选 `multispace/`，Sync 后 `Build → Generate Signed Bundle / APK`。

---

## 四之二、没有电脑：纯手机云端出包（推荐）

思路：**让云端 CI 替你跑 Gradle**，手机浏览器全程操作，产出的是 debug APK（自带 Android 默认 debug 签名，点开就能装，不需要 keystore）。工程里已带 `.github/workflows/build-apk.yml`，随包另附一份 `多域_无电脑打包_工作流.yml` 供手机复制粘贴。

### GitHub Actions 步骤（手机操作）

1. 手机浏览器登录 github.com → 新建仓库（建议名 `multispace`，Public 即可）。
2. `Add file → Create new file`，**文件名填完整路径** `.github/workflows/build-apk.yml`（GitHub 会自动建目录），把 `多域_无电脑打包_工作流.yml` 的内容整段粘贴进去，提交。此时会触发一次构建但会自动跳过（仓库还没源码），属正常。
3. `Add file → Upload files`，把工程 zip **改名为 `source.zip`** 后上传到仓库根目录并提交。这一步会自动触发真正构建。
4. 打开 `Actions` 页 → 等绿勾（首次约 5–10 分钟，要下 Gradle 和 SDK）→ 点进运行记录 → 底部 `Artifacts` 下载 `MultiSpace-debug-apk` → 解压得到 `app-debug.apk`。
5. 用手机文件管理器点 APK 安装（先允许浏览器/文件管理器「安装未知应用」）。以后改代码只需重新上传 zip，也可在 Actions 里 `Run workflow` 手动重跑。

> Artifact 默认保留 30 天，出来后及时下载。

### 国内访问 GitHub 慢

用 **cnb.cool**（微信登录、有 Android CI 模板，免费额度含 160 核时/月构建资源）：导入同一份仓库后，在模板里把 `BUILD_COMMAND` 填 `cd multispace && ./gradlew assembleDebug`、`ARTIFACT_PATH` 填 `multispace/app/build/outputs/apk/debug/*.apk`，产物会从 Release 附件下载。Gitee Go 同理。

### 为什么不建议在手机上硬编

Termux + OpenJDK 17 + Gradle 理论能跑 debug 包，但 AGP 的 `aapt2` 没有官方 ARM64 版本，要换 Termux 自带版本并关掉资源优化；release 包还容易打出「安装时解析失败」的坏包，加上 Gradle/Kotlin 在手机上内存吃紧。云端 CI 干净得多，也不用装几个 GB 的 SDK。

### 一个绕不过去的运行时边界

打包能纯手机完成，但 **Shizuku 启动** 要看系统版本：Android 11+ 可用「无线调试」纯手机启动；Android 8–10 没有无线调试，必须电脑 adb 跑一次或设备已 root。若你的手机是 8–10 且借不到电脑，增强模式（2+N 开）用不了，**基础模式（零权限，主实例 + 厂商分身）依然完全可用**。

---

## 五、Shizuku 授权（一次性）

1. 安装 Shizuku（包名 `moe.shizuku.privileged.api`）。
2. 启动它（以 Shizuku 官方手册为准）：
   - **Android 11+**：开发者选项 → 打开「USB 调试」+「无线调试」→ Shizuku「通过无线调试启动」→ 用配对码配对（仅首次）→ 点启动。**全程不用电脑**；但系统限制每次重启手机后都要重新点一次启动（部分新版 Shizuku 支持信任 WLAN 自动启动，以你装的版本为准）。
   - **Android 8 ~ 10**：没有无线调试，必须电脑 adb 执行 App 内给出的启动命令，或设备已 root 直接 root 启动。
   - 小米 / POCO 还需打开「USB 调试(安全设置)」；ColorOS 需关闭「权限监控」。
3. 回到「多域」→ 点「+ 新建空间」→ 在权限弹窗里允许。

不装 Shizuku 也完全可用：基础模式照样列出所有实例并一键原生启动，只是不能叠加空间。

---

## 六、各 ROM 注意点

| 机型 | 现象 / 处理 |
|---|---|
| 小米 / Redmi / POCO | `INSTALL_FAILED_USER_RESTRICTED`：开发者选项里打开「USB 调试(安全设置)」 |
| OPPO / 一加 / realme | ColorOS 总 profile 上限约 4–5，先删除不用的空间；打开「设置 → 多用户」开关 |
| 三星 OneUI | Knox 企业策略可能禁工作资料，代码会自动降级成普通 secondary user |
| ZTE / 努比亚 | 普通用户可能报「Maximum user limit」，代码优先用 managed profile 的独立配额 |
| 类原生 / AOSP | 本来就没有厂商分身页，直接用「+ 新建空间」，体验最干净 |

「系统分身设置」按钮里的 ComponentName 是**按机型/版本会变化的参考值**：跳转前逐个 `resolveActivity` 校验，失败自动降级到应用设置页 / 设置首页，并给出手动路径文字。跳不准时把正确组件追加到 `OemRoutes.kt` 的 `candidates` 即可，**主流程完全不依赖它**。

---

## 七、必须知道的边界

1. **金融、支付、部分游戏会主动检测多用户 / 工作资料环境并拒绝运行**，这是应用方风控，不是本工程的缺陷。
2. 一台设备的工作资料槽位可能已被厂商分身占满。代码先试 `pm create-user --profileOf 0 --managed`，失败自动降级 `pm create-user` 建普通用户。普通用户不出现在 `LauncherApps.getProfiles()`，启动改走 `am start --user`。
3. **Android 14+ 的后台跨用户启动限制**：从「多域」前台点击最稳。若要做桌面一键快捷方式，建议扩展 `ShortcutManagerCompat` + 前台 trampoline Activity（见下）。
4. 每个自建空间都是 `pm list users` 里真实的系统用户，**删除空间会清掉其中全部账号数据**；代码对 User 0 做了硬保护，永不删除主用户。
5. 通知、角标、耗电统计由系统按用户隔离展示，本应用不读取、不转发、不上传任何应用数据；Manifest 里零 `uses-permission`。
6. 极少数 ROM 上 `pm create-user --managed` 返回失败但实际已建用户，可用 `adb shell pm list users` 自查并用 `pm remove-user <id>` 清理孤儿用户。

---

## 八、可扩展方向

- 桌面快捷方式：`ShortcutManagerCompat.pushDynamicShortcut` / `requestPinShortcut`，指向一个前台 trampoline 再启动空间应用，绕开后台启动限制。
- `CrossProfileApps.startMainActivity()`（API 28+）：同一应用在个人 / 工作资料间切换的官方入口。
- `--user-type android.os.usertype.profile.CLONE`（Android 12+ 部分 ROM）：更轻量的克隆资料类型，可作为 managed profile 的另一种降级。
- `am stop-user <id>` / `am start-user <id>`：冻结不用的空间省电。
- 空间内应用批量安装、`pm list users` 可视化、实例数量上限提示。

---

## 九、依赖与许可

AndroidX / Material Components（Apache-2.0）、Shizuku API + Provider（Apache-2.0，RikkaApps）。本工程源码可自由修改，用于个人设备；请遵守目标应用的服务条款。
